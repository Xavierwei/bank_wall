<?php
$I = new WebGuy($scenario);
$I->wantTo('perform actions and see result');
