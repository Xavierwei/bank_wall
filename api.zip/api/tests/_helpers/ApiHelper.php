<?php
namespace Codeception\Module;

// here you can define custom functions for ApiGuy 

class ApiHelper extends \Codeception\Module
{
}
